# Claude Code Prompt: Integrate Strategic Context Files

Copy and paste this prompt into Claude Code:

---

```
I've added comprehensive strategic context files to the context/ folder. Update the AI CFO system to use them:

NEW FILES:
- business_context.yaml - Company info, BRIANN product details, services-to-platform transition strategy
- risks.yaml - Risk management framework with severity levels and mitigations
- metrics.yaml - KPIs to track (services health, product metrics, cost metrics, pipeline health)
- goals.yaml - Exit thesis (£35-50M by 2030), financial targets, operational milestones
- pipeline.yaml - Sales pipeline with 24 deals (already added)
- clients.yaml - Client portfolio with contracts (already added)

TASKS:

1. Update backend/context/loader.py:
   - Load all 6 YAML files
   - Add helper functions:
     - get_critical_risks() - returns risks with severity="Critical"
     - get_current_metrics() - returns key current state metrics
     - get_q1_goals() - returns Q1 2026 operational goals
     - get_transition_status() - returns services vs platform revenue mix

2. Update backend/ai/prompts.py - enhance the DAILY_INSIGHTS_SYSTEM prompt to understand:
   - The business is transitioning from 100% services to platform
   - BRIANN is being productised (Ferring pilot is first external deployment)
   - Exit thesis: £35-50M by 2030 requires 90% platform revenue by 2027
   - Current gross margin is 94% but will decrease as platform scales
   - ViiV/GSK concentration (~50%) is a critical risk

3. Update build_daily_prompt() to include:
   - Critical risks from risks.yaml
   - This week's key milestones from goals.yaml
   - Pipeline deals closing this month
   - Transition progress (services vs platform mix)
   - Any metrics that are outside target ranges

4. Add a new function build_strategic_context_summary() that creates a concise summary of:
   - Current financial position (£1.3M revenue, 94% GM, 11% NM)
   - Transition status (100% services → target 25% platform by end 2026)
   - Top 3 risks with mitigation status
   - Key milestones for next 90 days
   
   This should be included in all prompts so Claude always has strategic context.

5. Test by printing the full daily insights prompt to verify it includes:
   - Specific deal names and values
   - Risk alerts
   - Strategic context about the transition
   - Relevant milestones
```

---

## After Running That Prompt

Test the enhanced system with:

```bash
curl http://localhost:5000/api/ai/daily-insights
```

The insights should now reference:
- The services-to-platform transition
- Specific risks (ViiV concentration, API costs)
- Pipeline deals by name and value
- Strategic milestones

If insights are still too generic, follow up with:

```
The daily insights are missing strategic context. Check that:
1. build_strategic_context_summary() is being called
2. The summary is included in the user prompt
3. Print the full prompt being sent to Claude so I can see what it receives
```
